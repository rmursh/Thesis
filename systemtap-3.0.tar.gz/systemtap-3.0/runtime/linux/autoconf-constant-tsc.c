#include <asm/cpufeature.h>

int x = X86_FEATURE_CONSTANT_TSC;
