#include <linux/module.h>

struct module_layout ml;
