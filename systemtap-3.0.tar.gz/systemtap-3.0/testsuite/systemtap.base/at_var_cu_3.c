static int counter;

void
baz(void)
{
  counter = 3;
}

void
bah(void)
{
  counter--;
}
